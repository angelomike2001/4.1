package com.example.tddactivity

import android.content.Intent
import android.os.Bundle
import android.os.Parcelable
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.parcelize.Parcelize
import java.util.*
import kotlin.concurrent.schedule

/* -------------------- DATA MODEL -------------------- */
@Parcelize
data class ItemModel(val text: String) : Parcelable

/* -------------------- TEXT PROVIDER -------------------- */
class TextProvider {
    fun itemText(position: Int): String = "Item $position"
}

/* -------------------- ITEM LOADER -------------------- */
class ItemLoader(private val textProvider: TextProvider) {
    private val timer = Timer()
    fun load(count: Int, callback: (List<ItemModel>) -> Unit) {
        timer.schedule(1000L) {
            val list = (1..count).map { ItemModel(textProvider.itemText(it)) }
            callback(list)
        }
    }
}

/* -------------------- RECYCLER ADAPTER -------------------- */
class ItemAdapter(private val onClick: (ItemModel) -> Unit) :
    RecyclerView.Adapter<ItemAdapter.VH>() {

    private val items = mutableListOf<ItemModel>()

    @Suppress("NotifyDataSetChanged")
    fun setItems(list: List<ItemModel>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_1, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.text.text = item.text
        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size
}

/* -------------------- ACTIVITY 1 -------------------- */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val input = EditText(this).apply {
            hint = getString(R.string.enter_number)
            inputType = InputType.TYPE_CLASS_NUMBER
        }

        val btn = Button(this).apply {
            text = getString(R.string.go)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            addView(input)
            addView(btn)
        }

        setContentView(layout)

        btn.setOnClickListener {
            val num = input.text.toString().toIntOrNull() ?: 0
            val intent = Intent(this, ListActivity::class.java)
            intent.putExtra("count", num)
            startActivity(intent)
        }
    }
}

/* -------------------- ACTIVITY 2 -------------------- */
class ListActivity : AppCompatActivity() {

    private lateinit var loader: ItemLoader
    private lateinit var adapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val textProvider = TextProvider()
        loader = ItemLoader(textProvider)

        val recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@ListActivity)
        }

        adapter = ItemAdapter { item ->
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("itemText", item.text)
            startActivity(intent)
        }

        recycler.adapter = adapter
        setContentView(recycler)

        val count = intent.getIntExtra("count", 0)
        loader.load(count) { list ->
            runOnUiThread { adapter.setItems(list) }
        }
    }
}

/* -------------------- ACTIVITY 3 -------------------- */
class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val itemText = intent.getStringExtra("itemText") ?: ""

        val textView = TextView(this).apply {
            text = getString(R.string.you_clicked, itemText)
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(16, 16, 16, 16)
        }

        setContentView(textView)
    }
}
